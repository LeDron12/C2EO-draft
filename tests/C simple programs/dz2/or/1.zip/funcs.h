int task01(char *nameA, char *nameB, char* s);

int task02(char *nameA, char *nameB, char* s);

int task03(char *nameA, char *nameB, char* s);

int task04(char *nameA, char *nameB, char* s);

int task05(char *nameA, char *nameB, char* s);



