double norm(double* b, int n);
int solve(double *a, double *b, double *x, int n);